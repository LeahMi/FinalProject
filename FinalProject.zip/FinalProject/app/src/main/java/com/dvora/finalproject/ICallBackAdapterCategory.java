package com.dvora.finalproject;

import com.dvora.finalproject.entities.Category;

public interface ICallBackAdapterCategory {

        void onClickItem(Category category);
}
