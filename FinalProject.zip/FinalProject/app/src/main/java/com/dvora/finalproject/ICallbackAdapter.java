package com.dvora.finalproject;

import com.dvora.finalproject.entities.Recipe;

public interface ICallbackAdapter {
    void onClickItem(Recipe recipe);
}
