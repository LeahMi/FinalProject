package com.dvora.finalproject.fragments;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.work.Data;

import com.dvora.finalproject.FirebaseManager;
import com.dvora.finalproject.R;
import com.dvora.finalproject.Repository;
import com.dvora.finalproject.activities.Login;
import com.dvora.finalproject.activities.MainActivity;
import com.dvora.finalproject.entities.Category;
import com.dvora.finalproject.entities.User;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ProfileFragment extends Fragment {
    private Repository repo = new Repository();
    private TextView Name;
    private TextView Mail;
    private Button logOut;
    private TextView tv_c;
    boolean[] selectC;
    ArrayList<Integer> cList= new ArrayList<>();
    String[] cArray ;

    public ProfileFragment() {


    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_profile, container, false);
        logOut = (Button) v.findViewById(R.id.log_out);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getActivity(), Login.class));
            }
        });

        repo.getAllCategories(new Repository.OnSearchAllCategories() {
            @Override
            public void onCategoriesFound(List<Category> matches) {

                cArray= new String[matches.size()];
                selectC = new boolean[cArray.length];
                for(int i=0;i<matches.size();++i)
                {
                    cArray[i]=matches.get(i).getName();
                }
            }

            @Override
            public void onNoCategoriesFound(String message) {

            }

            @Override
            public void onExceptionOccurred(Exception e) {

            }
        });


        tv_c = v.findViewById(R.id.tv_name_c);
        StringBuilder stringBuilder = new StringBuilder();
        tv_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new  AlertDialog.Builder(

                        getContext()
                );
                builder.setTitle("קטגוריה אהובה");
                builder.setCancelable(false);
                builder.setMultiChoiceItems(cArray, selectC, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i, boolean b) {

                      if (b){
                          cList.add(i);
                          Collections.sort(cList);

                      }else {
//                          if(cList.size()==1)
//                          {

                              selectC[i]=false;
                              cList.clear();
                              stringBuilder.delete(cList.get(i),cList.get(i));


//                          }
//                          else cList.remove(i);
                      }
                    }
                });

                builder.setPositiveButton("אישור", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
//                        StringBuilder stringBuilder = new StringBuilder();
                        for(int j=0;j<cList.size();j++)
                        {
                            stringBuilder.append(cArray[cList.get(j)]);

                            if(j!=cList.size()-1){

                                stringBuilder.append(", ");

                            }
                        }

                        tv_c.setText(stringBuilder.toString());

                    }
                });

                builder.setNegativeButton("בטל", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.dismiss();

                    }
                });

                builder.setNeutralButton("נקה הכל", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        for(int j=0; j<selectC.length;++j){
                            selectC[j]=false;
                            cList.clear();
                            tv_c.setText("");
                        }

                    }
                });

                builder.show();


            }
        });


        Name= (TextView) v.findViewById(R.id.texthello);

        repo.getProfile(new Repository.OnSearchProfile() {
            @Override
            public void onSuccess(String message) {
                Name.setText("שלום "+ message);
            }

            @Override
            public void onFailure(Exception e) {

            }
        });

        Mail = v.findViewById(R.id.mail);
        Mail.setText(FirebaseManager.currentUser.getEmail());

        return v;
    }
}